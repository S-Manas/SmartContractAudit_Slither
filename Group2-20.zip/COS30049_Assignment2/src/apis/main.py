from fastapi import FastAPI, File, UploadFile
import mysql.connector
from fastapi.middleware.cors import CORSMiddleware
import subprocess
import re
from datetime import date
import json

# run solc function
def run(command):
  try:
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    print(result.stdout)
  except subprocess.CalledProcessError as e:
    print(f"Command '{' '.join(command)}' failed with error:\n", e)

    print("Error output:", e.stderr, "haha")
  except Exception as e:
    print("An error occurred:", e)
    print(command)

# run slither function
def run_slither(command):
  try:
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    print ("Success")
    return result.stdout
  except subprocess.CalledProcessError as e:
    return "Failed"
  except Exception as e:
    print("An error occurred:", e)


# return solidity compiler version from a .sol file
def getSolidVer(text):
  line = re.search("pragma\s+solidity.+\d+\.\d+\.\d+;", text).group()
  ver = re.search("\d+\.\d+\.\d+", line).group()
  return ver

# init fastapi
app = FastAPI()

#security
origins = ["*"]
app.add_middleware(
  CORSMiddleware,
  allow_origins=origins,
  allow_credentials=True,
  allow_methods=["*"],
  allow_headers=["*"],
)

# database settings and connection
db_config = {
  "host": "feenix-mariadb.swin.edu.au",
  "user": "s103824041",
  "password": "111104",
  "database": "s103824041_db"
}

conn = mysql.connector.connect(**db_config)
cursor = conn.cursor(buffered=True,dictionary=True)



# upload file, store data into database, return json object to show result
@app.post("/upload/")
async def upload_file(file: UploadFile):

  # get file name
  contract_name = file.filename

  # read the upload file and store onto the server
  with open(f"" + contract_name, "wb") as f:
    f.write(file.file.read())

  # get contract full text
  with open(f"" + contract_name, "r") as f:
    text = f.read()
  # get solidity version
  ver = getSolidVer(text)


  # commands to install the compiler version
  commands = [
    "solc-select install " + ver,
    "solc-select use "+ ver,
  ]
  for cmd in commands:
    run(cmd)

  # run slither and write result into result.md
  temp = run_slither("slither " + contract_name + " --checklist")

  with open("result.md", "w") as f:
    f.write(temp)


  # get report text into a variable
  with open("./result.md", "r") as file:
    markdown_content = file.read()

  # pattern to get each vulnerabilities section
  results = {}

  # get sections
  section_pattern = r'(?m)^## ([-A-Za-z]+)\n(.*?)(?=^## [-A-Za-z]+\n|\Z)'
  sections_regex = re.findall(section_pattern, markdown_content, flags=re.DOTALL or re.MULTILINE)

  for section in sections_regex:
    header, content = section
    results[header] = content

  # get id,detail
  detail_pattern = r"(?m) - \[ \] ID-(?P<id>\d+)(?P<detail>.*?)(?= - \[ \] ID-|\Z)"
  #detail_pattern = r"(?m) - \[ \] ID-(?P<id>\d+)(?P<detail>.*?)(?P<line>(?= - \[ \] ID-|\Z))"

  results2 = {}
  # get all information
  for header, content in results.items():
    # detector information
    getDetectorInfoQuery = "select Impact, Confidence, Description, Recommendation from Detectors where Name = '" + header + "';"
    cursor.execute(getDetectorInfoQuery)
    detectorInfo = cursor.fetchall()
    impact = detectorInfo[0]['Impact']
    confidence = detectorInfo[0]['Confidence']
    description = detectorInfo[0]['Description']
    recommendation = detectorInfo[0]['Recommendation']

    results2[header] = {'vulList': [], 'impact': impact, 'confidence': confidence, 'description': description, 'recommendation': recommendation}

    # add all the vulnerabilities
    errors = re.finditer(detail_pattern, content, flags=re.DOTALL)
    for error in errors:
      results2[header]['vulList'].append({
        "id": error.group("id"),
        "detail": error.group("detail")
      })

  # get report summary and status
  status = ""
  summary_pattern = r"- \[(?P<issue_name>[\w-]+)\]\(#[\w-]+\) \((?P<results_count>\d+ results)\) \((?P<severity>[\w]+)\)"
  matches = re.findall(summary_pattern, markdown_content)
  summary = ""
  for match in matches:
    issue_name, results_count, severity = match
    if (summary == ""):
      status = severity
    summary += f"Issue Name: {issue_name}, Results Count: {results_count}, Severity: {severity} \n"

  # today date
  today = date.today()

  # insert Report information and get ReportID
  insertReportQuery = "insert into Reports (Date, ContractName, Summary, Status) values ('" + str(today) + "', '" + contract_name + "', '" + summary + "', '" + status + "');"
  try:
    cursor.execute(insertReportQuery)
    conn.commit()  # Commit the changes
    print ("report created successfully")
  except mysql.connector.Error as err:
    conn.rollback()  # Roll back the transaction in case of an error
    print("Error:" + str(err))

  # get report id
  getReportIDQuery = "select ReportID from Reports order by ReportID desc limit 1;"
  cursor.execute(getReportIDQuery)
  result = cursor.fetchall()
  reportID = result[0]["ReportID"]

  # get the detectors data
  for detector in results2:
    getDetectorIDQuery = "select DetectorID from Detectors where Name = '" + detector +"';"
    detectorID = 0
    try:
      cursor.execute(getDetectorIDQuery)
      conn.commit()
      result = cursor.fetchall()
      detectorID = result[0]["DetectorID"]
    except mysql.connector.Error as err:
      conn.rollback()
      print("Error:" + str(err))

    # insert vulnerabilities
    for vul in results2[detector]["vulList"]:
      vulnerID = vul["id"]
      detail = vul["detail"]

      insertVulQuery = "insert into Vulnerabilities (VulnerID, DetectorID, Detail, ReportID) values (" + str(vulnerID) + ", " + str(detectorID) + ", '" + detail + "', " + str(reportID) + ");"
      try:
        cursor.execute(insertVulQuery)
        conn.commit()
      except mysql.connector.Error as err:
        conn.rollback()
        print("Error:" + str(err))

  #format the return json object
  return_dict = {
    'contractName': contract_name,
    'contractID': reportID,
    'status': status,
    'date': str(today),
    'summary': summary,
    'allData': results2
  }
  return json.dumps(return_dict)

# get data json object given contract id
@app.get("/contractID/{id}")
async def getResultFromContractID(id: int):
  obj = {}

  # get contract information
  query = "select ContractName, Date, Status, Summary from Reports where ReportID = " + str(id) + ";"
  cursor.execute(query)
  result = cursor.fetchall()

  obj['contractName'] = result[0]['ContractName']
  obj['contractID'] = id
  obj['date'] = str(result[0]['Date'])
  obj['status'] = result[0]['Status']
  obj['summary'] = result[0]['Summary']
  obj['allData'] = {}

  # get detectors and vulnerabilities and pack into json data
  query2 = "select DetectorID from Vulnerabilities where ReportID = " + str(id) + " group by DetectorID order by VulnerID asc;"
  cursor.execute(query2)
  results = cursor.fetchall()
  for result in results:
    detectorID = result['DetectorID']
    query3 = "select Name, Impact, Confidence, Description, Recommendation from Detectors where DetectorID = " + str(detectorID) + ";"
    cursor.execute(query3)
    result3 = cursor.fetchall()
    name = result3[0]['Name']
    obj['allData'][name] = {
      'impact': result3[0]['Impact'],
      'confidence': result3[0]['Confidence'],
      'description': result3[0]['Description'],
      'recommendation': result3[0]['Recommendation'],
      'vulList': []
    }

    query4 = "select VulnerID, Detail from Vulnerabilities where DetectorID = " + str(detectorID) + " and ReportID = " + str(id) + " order by VulnerID asc;"
    cursor.execute(query4)
    result4 = cursor.fetchall()
    for r4 in result4:
      obj['allData'][name]['vulList'].append({
        "id": r4['VulnerID'],
        "detail": r4['Detail']
      })

  return json.dumps(obj)


# return an array that show brief detail when searching for a past report
@app.get("/search/{search}")
async def getHistory(search: str):
  # if contract id entered:
  if search.isnumeric():
    # get contract name, date, status
    query = "select ContractName, Date, Status from Reports where ReportID = " + search + ";"
    cursor.execute(query)
    result = cursor.fetchall()
    contractName = result[0]['ContractName']
    _date = result[0]['Date']
    status = result[0]['Status']

    # get no of vulnerabilities
    query = "select VulnerID from Vulnerabilities where ReportID = " + search + " order by VulnerID desc limit 1;"
    cursor.execute(query)
    result = cursor.fetchall()
    noOfVul = result[0]['VulnerID']

    return [{
      'contractID': int(search),
      'contractName': contractName,
      'date': _date,
      'noOfVul': noOfVul,
      'status': status
    }]
  else:
    # if contract name is entered, find by name instead of id
    rows = []
    query = "select ReportID, ContractName, Date, Status from Reports where ContractName like '%" + search + "%';"
    cursor.execute(query)
    results = cursor.fetchall()
    for result in results:
      reportID = result['ReportID']
      contractName = result['ContractName']
      _date = result['Date']
      status = result['Status']
      q = "select VulnerID from Vulnerabilities where ReportID = " + str(reportID) + " order by VulnerID desc limit 1;"
      cursor.execute(q)
      x = cursor.fetchall()
      noOfVul = x[0]['VulnerID']
      rows.append({
        'contractID': reportID,
        'contractName': contractName,
        'date': _date,
        'noOfVul': noOfVul,
        'status': status
      })
    return rows