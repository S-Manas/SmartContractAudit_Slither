import * as React from 'react'
import './styles/home_style.css'

import { NavBar } from './components/NavBar';
import { Home } from './pages/Home';
import { ContractAuditor } from './pages/ContractAuditor';
import { History } from './pages/History';
import { Results } from './pages/Results';
import { Login } from './pages/Login'
import { Account } from './pages/Account'
import { Route, Routes } from 'react-router-dom'

export default function App() {
  return (
    <>

      <NavBar />
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/contract_auditor" element={<ContractAuditor/>} />
        <Route path="/history" element={<History/>} />
        <Route path="/results" element={<Results/>} />
        <Route path="/login" element={<Login/>} />
        <Route path="/account" element={<Account />} />
      </Routes>


    </>
  )
}
