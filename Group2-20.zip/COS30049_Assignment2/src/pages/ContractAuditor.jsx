//Manas Sowale (ID: 103809297), Neel Patel (ID:103996924), Minh Thanh Dang (ID: 103824041)

import '../styles/home_style.css'
import axios from 'axios';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';


export function ContractAuditor() {
  const [file, setFile] = useState("")

  const navigate = useNavigate()

  // when change file, set file state again
  const changeHandler = (event) => {
    setFile(document.getElementById("file_input").files[document.getElementById("file_input").files.length - 1]);
    console.log(document.getElementById("file_input").files)
  }

  // when file change, check if file is valid (.sol) and display proper message
  useEffect(() => {
    if (file != ""){
      let main_msg = document.querySelector(".dynamic-message");
      if (!file.name.endsWith(".sol")){
        main_msg.innerHTML = 'Invalid file extension <p style="font-size:24px; color:red">Only .sol files are allowed</p>';
        document.querySelector(".errorMsg").style.cssText = "display: flex; animation: fadeIn linear 1.5s;";
      } else {
        main_msg.innerHTML = 'check_circle';
        document.querySelector(".dynamic-message").innerHTML = 'File Dropped Successfully!';
        document.querySelector(".file-name").innerHTML = file.name;
        document.querySelector(".file-size").innerHTML = (file.size / 1024).toFixed(1) + " KB";
        document.querySelector(".errorMsg").style.cssText = "display: none;";
        document.querySelector(".file-block").style.cssText = "display: flex;";
        document.querySelector(".progress-bar").style.width = 0;
        document.querySelector(".remove-file-icon").addEventListener("click", () => {
          document.querySelector(".file-block").style.cssText = "display: none;";
          document.querySelector(".default-file-input").value = '';
          document.querySelector(".upload-icon").innerHTML = 'file_upload';
          document.querySelector(".dynamic-message").innerHTML = 'Drag & drop any file here';
          setFile("")
        });
      }
    }

  }, [file])

  // when press upload, check if user has upload a correct file. If correct then call api to insert data to the database and get the data back and navigate to results page
  const handleSubmission = async () => {

    if (file == ""){
      document.querySelector(".dynamic-message").innerHTML = 'Please select a file';
    } else {
      const formData = new FormData();
      formData.append('file', file);

      if (!file.name.endsWith(".sol")){

      } else {
        document.querySelector(".dynamic-message").innerHTML = 'Uploading, please wait';
        try {
          await axios
            .post("http://127.0.0.1:8000/upload/", formData, {
              headers: {
                'Content-Type': 'multipart/form-data',
              },
            })
            .then((response) => {
              const data = JSON.parse(response.data);
              navigate('/results', {
                state: {
                  content: data
                }
              })
            });
        } catch (error) {
          document.querySelector(".dynamic-message").innerHTML = 'Connection error, could not upload file. Please try again';
        }
      }
    }

  }

  return (
    <div>
      {/* a box in the middle of the screen to drop file */}

      <form className="form-container" encType='multipart/form-data'>
        <div className="upload-files-container">
            <div className="drag-file-area">
                <span className="material-icons-outlined upload-icon"> file_upload </span>
                <h3 className="dynamic-message"> Drag & drop any file here </h3>
                <label className="label">
                  <span className="browse-files">
                    <input type="file" name="file" id="file_input" className="default-file-input" onChange={changeHandler}/>
                    <span className="browse-files-text">Browse File </span>
                    <span>from device</span>
                  </span>
                </label>
            </div>

            <span className="errorMsg"> <span className="material-icons-outlined">error</span> Please select a valid file <span className="material-icons-outlined cancel-alert-button">cancel</span> </span>

            <div className="file-block">
                <div className="file-info"> <span className="material-icons-outlined file-icon">description</span> <span className="file-name"> </span> | <span className="file-size">  </span> </div>
                <span className="material-icons remove-file-icon">delete</span>
                <div className="progress-bar"> </div>
            </div>
            <button type="button" className="upload-button" onClick={handleSubmission}> Upload </button>
        </div>
    </form>
    </div>
  )
}
