//Manas Sowale (ID: 103809297), Neel Patel (ID:103996924), Minh Thanh Dang (ID: 103824041)

export function Home() {
  return (
    <>

    {/* Section 1 */}
    <section className="home" id="home">
      <div className="content">
          <h1>SMART<br/>CONTRACT <br/> AUDIT SYSTEM</h1>
          <h2>COS30049</h2>
          <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sequi culpa quo nam consequatur nesciunt quos ipsam! Est consequuntur tenetur at dolore rem atque, suscipit iure quisquam eum, quasi, repudiandae sequi.</p>
      </div>

      <div className="image">
          <img src="images/web-interface.svg" alt="web-interface"/>
      </div>
    </section>

    {/* Section 2 */}
    <section className="info" id="info">
      <div className="heading">
          <h1>About <br/> Smart Contract Auditing</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo officiis sapiente laudantium architecto aspernatur nostrum excepturi quasi necessitatibus inventore! Fuga eligendi eos sed ipsa corporis ab. Repellat ipsam dolores quam!</p>
      </div>

    <div className="box-container">
        <div className="box">
            <img src="images/Solidity-logo.png" alt="logo-solodity" />
            <h3>Solidity</h3>
            <br/><br/><br/>
            <a href="https://soliditylang.org/" className="all-btn">Explore</a>
        </div>

        <div className="box">
            <img src="images/eth-logo.webp" alt="logo-eth" />
            <h3>Ethereum</h3>
            <br/><br/><br/>
            <a href="https://ethereum.org/en/" className="all-btn">Explore</a>
        </div>
    </div>

    {/*Section 3 */}
    </section>
    <section className="contractAuditor" id="contractAuditor">
        <div className="heading1">
            <h1>Our Services</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sed quas velit illum, tempore eaque culpa dignissimos ipsum tenetur suscipit rem, iusto ducimus blanditiis nemo earum explicabo ullam aut quidem facilis.</p>
        </div>

        <div className="row">
            <div className="image">
                <img src="images/submit-file.svg" alt="submit-file"/>
            </div>
            <div className="content">
                <h1>Submit A File</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi sint odit tempora, maiores quos qui quisquam accusamus ad officiis sapiente.</p>
                <a href="contractAuditor.html" className="all-btn">Get Started</a>
            </div>


            <div className="content">
                <h1>Results</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas consequatur eligendi quis labore rerum. Placeat magnam officiis cum, dolor odit neque perspiciatis accusantium dolorem, repellendus modi, obcaecati ab adipisci consectetur!</p>
                <a href="results.html" className="all-btn">View Now</a>
            </div>
            <div className="image">
                <img src="images/results.svg" alt="results"/>
            </div>


            <div className="image">
                <img className="login" src="images/login.jpg" alt="login"/>
            </div>
            <div className="content">
                <h1>History</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde reiciendis asperiores excepturi iure fugiat saepe autem atque fuga quod itaque, blanditiis vel harum dolores laborum maxime corporis magni quia ullam?</p>
                <a href="login.html" className="all-btn">Login To View</a>
            </div>
        </div>
    </section>

    {/* footer */}
    <section className="footer" id="footer">
       <div className="box-container">
            <div className="box">
                <h3>Website Links</h3>
                <a href="index.html"><i className="fas fa-chevron-right"></i>home</a>
                <a href="contractAuditor.html"><i className="fas fa-chevron-right"></i>contract auditor</a>
                <a href="history.html"><i className="fas fa-chevron-right"></i>history</a>
                <a href="results.html"><i className="fas fa-chevron-right"></i>results</a>
                <a href="login.html"><i className="fas fa-chevron-right"></i>login</a>
            </div>

            <div class="box">
                <h3>Contact Info</h3>
                <a href="#"><i className="fas fa-phone"></i>041-234-5678</a>
                <a href="#"><i className="fas fa-phone"></i>041-222-3333</a>
                <a href="#"><i className="fas fa-envelope"></i>123456789@student.swin.edu.au</a>
                <a href="#"><i className="fas fa-envelope"></i>123456789@student.swin.edu.au</a>
                <a href="#"><i className="fas fa-map-marker-alt"></i>Swinburne University of Technology, Hawthorn, VIC, Australia</a>
            </div>
       </div>

       <div className="groupInfo">
           <p>Group 2-20<br />COS30049 Computing Technology Innovation Project</p>
       </div>
    </section>

    </>
  )
}
