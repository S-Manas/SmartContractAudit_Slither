//Manas Sowale (ID: 103809297), Neel Patel (ID:103996924), Minh Thanh Dang (ID: 103824041)

import { useState } from "react"
import { Grid } from '@mui/material'
import { SearchBar } from "../components/SearchBar";
import { HistoryTable } from '../components/HistoryTable';

import '../styles/history_style.css'
export function History() {
  const [searching, setSearching] = useState("")

  return (
    <container id="history_page">

      {/* title and information */}
      <Grid container spacing ={2} >
        <Grid item xs={12} sx={{textAlign: 'center'}}>
          <h1 className="page_title">HISTORY</h1>
          <h2 id="history_details">Find any smart contract online or login to see yours </h2>
          <br/>
        </Grid>

        {/* search bar */}
        <Grid item xs={12}>
          <SearchBar onSubmit={setSearching} />
        </Grid>

        <Grid item xs={12} sx={{marginLeft:'18vw'}}>
          <h2>Displaying result for "{searching}"</h2>
        </Grid>

        {/* result table */}

        <Grid item xs={12} align='center' sx={{maxWidth: 800}}>
          <HistoryTable searching={searching} />
        </Grid>

        <Grid item xs={9}></Grid>
        <Grid item xs={2}></Grid>

      </Grid>



    </container>
  )
}
