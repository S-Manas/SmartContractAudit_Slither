//Manas Sowale (ID: 103809297), Neel Patel (ID:103996924), Minh Thanh Dang (ID: 103824041)

import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';
import '../styles/history_style.css';
import { Grid } from "@mui/material"
import {Paper} from "@mui/material"
import {Box} from "@mui/material"
import { createTheme, ThemeProvider, styled } from '@mui/material/styles';
import { Button } from "@mui/material";
import { Link } from 'react-router-dom';


export function Account() {
  // style boxes
  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    fontSize: '20px',
    wordSpacing: '4.3px',
    lineHeight: '35px',
    color: theme.palette.text.secondary,
    padding: '4rem',
    paddingLeft: '8rem',
    paddingRight: '8rem'
  }));
  const Item2 = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    fontSize: '20px',
    wordSpacing: '4.3px',
    lineHeight: '35px',
    color: theme.palette.text.secondary,
    padding: '4rem',
    paddingRight:'6rem',
    paddingTop: '2rem'
  }));
  const darkTheme = createTheme({ palette: { mode: 'dark' } });

  return (
    <>
      {/* avatar */}
      <Avatar src="/broken-image.jpg" sx={{margin: 'auto', marginTop: '50px', height: '200px', width: '200px'}}/>

      {/* profile layout */}
      <ThemeProvider theme={darkTheme} >
        <Box
          sx={{
            p: 2,
            bgcolor: 'background.default',
            display: 'grid',
            height: '50vh',
            gridTemplateColumns: { md: '1.5fr 1fr' },
            gap: 2,
            margin: '3rem 13rem'
          }}
        >
          <Item elevation={3}>
            <h3>Account Name: zaa jahf fda</h3>
            <h3>Account ID: 234234231455</h3>
            <h3>Email: safhjlsa@hjfasd.com</h3>
          </Item>
          <Item2 elevation={3}>
            <h3> Recent Activity</h3>
            <Box component="div" sx={{ p: 2, border: '1px dashed white', width: '100%'}}>
              <span>Smart Contract 1</span>
              <span> Vulnerabilities: 3</span>
              <br/>
              <Button component={Link} to={'/results'}>Details</Button>
              <Button>Delete</Button>
            </Box>
            <Box component="div" sx={{ p: 2, border: '1px dashed white', width: '100%'}}>
              <span>Smart Contract 2</span>
              <span> Vulnerabilities: 3</span>
              <br />
              <Button component={Link} to={'/results'}>Details</Button>
              <Button>Delete</Button>
            </Box>
            <Box component="div" sx={{ p: 2, border: '1px dashed white', width: '100%'}}>
              <span>Smart Contract 3</span>
              <span> Vulnerabilities: 4</span>
              <br />
              <Button component={Link} to={'/results'}>Details</Button>
              <Button>Delete</Button>
            </Box>
          </Item2>
        </Box>
      </ThemeProvider>
    </>
  )
}
