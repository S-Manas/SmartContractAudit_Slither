//Manas Sowale (ID: 103809297), Neel Patel (ID:103996924), Minh Thanh Dang (ID: 103824041)

import { useState, useEffect } from "react"
import { Grid } from "@mui/material"
import {Paper} from "@mui/material"
import {Box} from "@mui/material"
import { createTheme, ThemeProvider, styled } from '@mui/material/styles';
import { useLocation } from 'react-router-dom';



export function Results() {
  const location = useLocation();

  const [data, setData] = useState({})
  const [content, setContent] = useState("testcontent")
  const [allData, setAllData] = useState({})
  const [header, setHeader] = useState("Report Summary")


  // whenever redirected to this page, check what data is passed and set the corresponding states
  useEffect(() => {
    setData(location.state.content)
    setContent(location.state.content.summary)
    setAllData(location.state.content.allData)
  }, [location])


  // style components
  const StyledVulBox = styled(Box)({
    '&:hover': {
      backgroundColor: 'lightyellow',
      color: 'black'
    }
  });

  const StyledSummary = styled(Box)({
    fontSize: '1.6rem',
    fontWeight: 'bold',
    '&:hover': {
      background: 'red',
      color: 'black'
    }
  });

  const Item = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    fontSize: '20px',
    wordSpacing: '4.3px',
    lineHeight: '35px',
    color: theme.palette.text.secondary,
    paddingTop: '1vh',
    paddingLeft: '1.25vw',
    paddingRight: '1.25vw'
  }));

  const Item2 = styled(Paper)(({ theme }) => ({
    ...theme.typography.body2,
    fontSize: '20px',
    wordSpacing: '4.3px',
    lineHeight: '35px',
    color: theme.palette.text.secondary,
    paddingLeft: '1.25vw',
    paddingTop: '1vh',
    paddingRight:'1.25vw'
  }));

  const darkTheme = createTheme({ palette: { mode: 'dark' } });

  const HighlightText = styled('span')(({ prop }) => ({
    background: '#ffff00',
    color: 'black'
  }));

  document.getElementById("big").style.fontSize = "100%"

  // when click on each id, show the vulnerability detail
  const handleHierarchyClick = (vul, key) => {
    setContent(vul.detail + "Description: " + allData[key].description + "\nSuggestion: " + allData[key].recommendation)
    setHeader("Vulnerability ID "+ vul.id)
  }

  // show the vulnerabilities
  const showVulIDs = (vulList, key) => (
    <div>
      {vulList.map((vul) => (
        <StyledVulBox
          sx={{ p: 0, border: '1px dashed orange', width: '86%', paddingLeft:'0.2rem', clear: 'right', color: 'white'}}
          onClick={() => handleHierarchyClick(vul, key)}
        >
          Show Vulnerability ID {vul.id}
        </StyledVulBox>
      ))}
    </div>
  );

  // show the detectors and vulnerabilities
  const hierarchy = Object.keys(allData).map((key) => (
    <Box component="div" sx={{ p: 2, border: '1px dashed white', width: '90%', paddingTop: '0rem', paddingLeft:'1rem'}}>
      <div style={{float: 'left', paddingTop:'1rem', fontWeight: 'bold', fontSize: '1.4rem'}}><HighlightText>{key}</HighlightText></div>
      <pre style={{float: 'right', color: 'red'}}>Impact: {allData[key].impact}<br style={{textSize: '0.1rem'}}/>Confidence: {allData[key].confidence}</pre>
      {showVulIDs(allData[key]['vulList'], key)}
    </Box>
  ));



  return (
    <>
      {/* dark background */}
      <Grid container spacing ={2} sx={{position: 'static', maxHeight: '88vh'}}>
        <Grid item xs={12} sx={{maxHeight: '88vh'}}>
          <ThemeProvider theme={darkTheme}>
            <Box
              sx={{
                p: 2,
                bgcolor: 'background.default',
                display: 'grid',
                height: '90vh',
                gridTemplateColumns: { md: '2.35fr 1fr' },
                gap: 2,
              }}
            >
              {/* code part */}
              <Item elevation={3} sx={{overflow: 'auto', maxHeight: '88vh'}}>
                <div style={{color: 'red', fontSize: '1.8rem', fontWeight: 'bold', display:'flex', justifyContent: 'center'}}>Contract name: {data.contractName}</div>
                <div style={{color: 'orange', fontSize:'1.5rem', fontWeight: 'bold', float: 'right', marginRight: '5vw'}}>Contract ID: {data.contractID}</div>
                <div style={{color: 'white', clear: 'both', fontSize: '1.5rem', fontWeight: 'bold', marginLeft: '4vw'}}>{header}</div>
                <pre>
                  {content}
                </pre>
              </Item>

              {/* vulnerabilities part */}
              <Item2 elevation={3} sx={{overflow: 'auto', maxHeight: '88vh'}}>
                <StyledSummary
                  style={{color: 'white', textAlign: 'center'}}
                  onClick={() => {
                    setContent(data.summary)
                    setHeader("Report Summary")
                  }}>
                  Show Summary
                </StyledSummary>
                <h3>Vulnerabilities</h3>
                {hierarchy}

              </Item2>
            </Box>
          </ThemeProvider>
        </Grid>
      </Grid>
    </>
  )
}
