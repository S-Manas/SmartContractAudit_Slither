//Manas Sowale (ID: 103809297), Neel Patel (ID:103996924), Minh Thanh Dang (ID: 103824041)

import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import Tooltip from '@mui/material/Tooltip';
import MenuItem from '@mui/material/MenuItem';
import { Link } from 'react-router-dom';
import { styled } from '@mui/material/styles';



export function NavBar() {
  const [anchorElUser, setAnchorElUser] = React.useState(null);

  // settings for react router
  const pages = [
    { name: 'Home', link: '/'},
    { name: 'Contract Auditor', link: '/contract_auditor'},
    { name: 'History', link: '/history'}
  ]
  const settings = [
    { name: 'Home', link: '/'},
    { name: 'Contract Auditor', link: '/contract_auditor'},
    { name: 'History', link: '/history'}
  ];


  //style search button
  const StyledButton = styled(Button) ({
    color: 'white',
    fontSize: '19px',
    fontFamily: 'Poppins',
    fontWeight: '600',
    marginLeft: '10px',
    textAlign: 'center'
  })

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  return (

    <AppBar sx={{backgroundColor:"#2C1E4A", height: '100px', position:'static'}}>
      <Toolbar >
        {/* logo */}
        <Typography component={Link} to="/"
          sx={{ fontWeight: 700, color: 'inherit', textDecoration: 'none', textAlign: 'left', margin:'auto', marginTop: '25px', marginLeft: '1rem'}}>
          <img src="images/logo/logo-no-background-white.png" alt="logo" height="50px" />
        </Typography>

        {/* links to pages */}
        <Box sx={{marginTop: '29px', display: {xs: 'none', md:'block'}}}>
          {pages.map((page) => (
            <StyledButton component={Link} to={page.link} key={page.name} >
              {page.name}
            </StyledButton>
          ))}
        </Box>

        <Box>
          {/* user avatar and drop down menu */}

          <Tooltip title="Open settings">
            <IconButton onClick={handleOpenUserMenu} sx={{ p: 0, paddingTop:'29px', paddingLeft: '29px' }} >
              <Avatar alt="user"> L </Avatar>
            </IconButton>
          </Tooltip>
          <Menu
            id="menu-appbar"
            anchorEl={anchorElUser}
            anchorOrigin={{
              vertical: 'bottom'
            }}
            keepMounted
            transformOrigin={{
              vertical: 'bottom',
              horizontal: 'center',
            }}
            open={Boolean(anchorElUser)}
            onClose={handleCloseUserMenu}
          >
            {settings.map((setting) => (
              <MenuItem key={setting.name} onClick={handleCloseUserMenu} component={Link} to={setting.link} >
                <Typography textAlign="center" sx={{fontSize: '1.5rem', margin: 'auto'}}>{setting.name}</Typography>
              </MenuItem>
            ))}
          </Menu>
        </Box>
      </Toolbar>
    </AppBar>
  );
}
