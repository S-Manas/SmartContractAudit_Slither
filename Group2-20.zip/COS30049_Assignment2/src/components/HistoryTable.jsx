//Manas Sowale (ID: 103809297), Neel Patel (ID:103996924), Minh Thanh Dang (ID: 103824041)

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles'
import { useState, useEffect} from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';


export function HistoryTable( { searching }) {
  const [rows, setRows] = useState([])

  const navigate = useNavigate()


  // if new search data is entered, fetch result and display again
  useEffect(() => {
    const fetchData = async () => {
      axios
      .get("http://127.0.0.1:8000/search/" + searching)
      .then((response) => {
        console.log(rows)
        setRows(response.data)
      })
      .catch((error) => {
        console.error("there are errors:", error);
      });
    }

    fetchData();
  }, [searching])


  // when press a row, navigate to the results page
  const chooseRow = async (row) => {

    axios
    .get("http://127.0.0.1:8000/contractID/" + row["contractID"])
    .then((response) => {
      const data = JSON.parse(response.data);
        navigate('/results', {
          state: {
            content: data
          }
        })
    })
    .catch((error) => {
      console.error("there are errors:", error);
    });

  }

  {/* style the table */}
  const TableHeadStyled = styled(TableHead) ({
    backgroundColor: '#1933a6',
  })

  const StyledTableHeader = styled(TableCell) ((props) => ({
    color: props.color,
    fontSize: '1.2rem',
    fontWeight: 'bold',
    padding: '10px'
  }))

  const StyledTableCell = styled(TableCell) ((props) => ({
    fontSize: '1.2rem',
    fontWeight: 'bold',
    borderWidth: '2.4px',
    borderColor: 'black',
    padding: '10px'
  }))

  const StyledTableRow = styled(TableRow)({
    '&:nth-of-type(odd)': {
      backgroundColor: 'lightgrey',
    },
    '&:nth-of-type(even)': {
      backgroundColor: 'white',
    },
    // hide last border
    '&:last-child td, &:last-child th': {
      border: 0,
    },
    '&:hover': {
      backgroundColor: 'lightyellow', // Change the background color on hover
    }
  });

  const StyledTableContainer = styled(TableContainer) ({
    boxShadow: '3px 3px 3px darkblue',
    borderRadius: '8px'
  })



  return (
    // create the table
    <StyledTableContainer sx={{ width: '80vw', minWidth: 400, maxWidth: 991,  align: 'center'}} component={Paper}>
      <Table >
        <TableHeadStyled>
          <TableRow>
            <StyledTableHeader color='white'>File ID</StyledTableHeader>
            <StyledTableHeader color='white'>File Name</StyledTableHeader>
            <StyledTableHeader color='white'>Date</StyledTableHeader>
            <StyledTableHeader color='white'>Vulnerabilities</StyledTableHeader>
            <StyledTableHeader color='white'>Severity</StyledTableHeader>
          </TableRow>
        </TableHeadStyled>
        <TableBody>
          { // create the rows
            rows.map((row) => (
            <StyledTableRow
              key={row["contractID"]} onClick={() => chooseRow(row)}
            >
              <StyledTableCell>{row["contractID"]}</StyledTableCell>
              <StyledTableCell>{row["contractName"]}</StyledTableCell>
              <StyledTableCell>{row["date"]}</StyledTableCell>
              <StyledTableCell>{row["noOfVul"]}</StyledTableCell>
              <StyledTableCell>{row["status"]}</StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </StyledTableContainer>
  )


}
