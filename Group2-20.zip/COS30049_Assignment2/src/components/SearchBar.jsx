//Manas Sowale (ID: 103809297), Neel Patel (ID:103996924), Minh Thanh Dang (ID: 103824041)

import { useState } from "react"
import { Grid } from '@mui/material'


export function SearchBar({ onSubmit }){
  //State of search bar text
  const [searchInput, setSearchInput] = useState("")

  //On submit, prevent page reload, do the function passed, then reset the search text
  function handleSubmit(e){
    e.preventDefault()

    onSubmit(searchInput)

    setSearchInput("")

  }

  return (
    <>
    {/*search bar*/}
    <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={2}></Grid>
          <Grid item xs={10}>
            <label htmlFor="search_input" ><h2 id="search_label" style={{fontSize: '2rem'}}>Find a smart contract by id / name</h2></label>
          </Grid>
          <Grid item xs={2}></Grid>

          <Grid item xs={7} >
            <input
              type="text"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              className="search_input"
              sx={{boxShadow: 5}}
            />
          </Grid>
          <Grid item xs={3}>
            <button className="btn">
              <span className="material-symbols-outlined">search</span>
            </button>
          </Grid>
        </Grid>
    </form>
    </>

  )


}
